# [Your Name] Photography — starter template

A basic 4-page photography site, ready for GitHub Pages: home, gallery
(empty, organized by category), about, and contact (email only).

## Files

```
index.html     Home page / hero
gallery.html   Empty galleries, grouped into categories
about.html     Short bio
contact.html   Email contact
style.css      All styling (edit the :root tokens at the top to re-skin)
script.js      Mobile nav toggle
```

## 1. Customize the text

Search every file for square brackets and replace them with your own info:

- `[Your Name]` → your name or studio name
- `[City, Country]` → where you're based
- `you@example.com` → your real email (appears in `contact.html` and the
  footer of every page)
- Gallery category names in `gallery.html` (currently "Portraits",
  "Weddings", "Travel") → whatever categories fit your work

## 2. Add real photos to the gallery

Each empty slot in `gallery.html` looks like this:

```html
<div class="frame">
  <span class="frame-number">N° 001</span>
  <div class="frame-empty"> ... </div>
</div>
```

Replace the `frame-empty` div with an image:

```html
<div class="frame">
  <span class="frame-number">N° 001</span>
  <img src="images/portraits/01.jpg" alt="Describe the photo">
</div>
```

Create an `images/` folder next to `index.html` (e.g. `images/portraits/`,
`images/weddings/`) and drop your photos in there. Keep photos close to a
3:2 aspect ratio for a tidy grid, and always write a real `alt` description.

## 3. Put it on GitHub Pages

1. Create a new repository on GitHub (e.g. `photography-site`, or
   `yourusername.github.io` if you want it at the root of your GitHub
   domain).
2. Upload all the files in this folder to the repository (drag-and-drop
   on github.com works fine, or `git add . && git commit -m "Site" && git push`).
3. In the repo, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source** to "Deploy from a branch",
   pick the `main` branch and the `/ (root)` folder, then **Save**.
5. GitHub will give you a URL like `https://yourusername.github.io/photography-site/`
   (or `https://yourusername.github.io/` if you used the special repo name).
   It can take a minute or two to go live.

That's it — no build step, no server, just static files.
